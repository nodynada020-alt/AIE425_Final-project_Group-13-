
# AIE425 SECTION1 Project: Intelligent Recommender Systems

## Project Overview
This project implements an intelligent recommender system using matrix factorization and dimensionality reduction techniques.  
The goal is to predict missing user-item ratings, analyze cold-start users, and evaluate performance across various methods.

Key techniques used:
- PCA with Mean-Filling
- PCA with Maximum Likelihood Estimation (MLE)
- SVD (Singular Value Decomposition)
- Sensitivity Analysis
- Cold-Start Analysis
- Hybrid recommendation strategies

________________________________________________________________________________________________________________________________

## Dataset

The dataset used in this project includes user-item ratings.  
You can either download the dataset from [MovieLens 25M](https://grouplens.org/datasets/movielens/25m/)  
or place your local CSV files in the `dataset/` folder as follows:

- dataset/ratings.csv : User-item ratings file  
- dataset/movies.csv : Movie metadata (optional for content-based analysis)

<Note>: Update the file paths in the notebooks if your dataset is stored in a different location.

________________________________________________________________________________________________________________________________

## Project Files

- main_notebook.ipynb : Jupyter Notebook containing the full analysis, code, visualizations, and results  
- dataset/ : Folder containing the dataset CSV files  
- README.md  : This file  
- requirements.txt  : Python dependencies

_______________________________________________________________________________________________________________________________

## Requirements

Python 3.10+ and the following packages:

<bash>
pip install -r requirements.txt
````

Contents of requirements.txt :

```
numpy
pandas
scipy
scikit-learn
matplotlib
seaborn
```

__________________________________________________________________________________________________________________________________

## Usage Instructions

1. Download the dataset and place it in the `dataset/` folder.
2. Open `main_notebook.ipynb` in Jupyter Notebook or VS Code.
3. Update the file paths if necessary.
4. Run the notebook cells sequentially from PART 1 to PART 3:

   <PART 1: PCA with Mean-Filling
   <PART 2: PCA with MLE
   <PART 3: SVD and Sensitivity/Cold-Start Analysis
5. Check visualizations, tables, and numeric results in each section.
6. All plots and metrics are saved within the notebook for discussion.

_____________________________________________________________________________________________________________________________________

## Results and Visualizations

. Reconstruction Error (RMSE) for each method
. Prediction Accuracy (MAE, RMSE)
. Sensitivity Analysis: Effect of missing ratings
. Cold-Start Analysis: Performance vs. number of ratings
. Hybrid approaches comparison
. All plots are included in the notebook cells for easy reference.

_____________________________________________________________________________________________________________________________________

## Notes

. Large datasets may require high RAM; consider using a subset for testing.
. Ensure reproducibility by setting random seeds where applicable.
. For the cold-start and sensitivity analyses, some preprocessing may take longer on full datasets.

______________________________________________________________________________________________________________________________________


