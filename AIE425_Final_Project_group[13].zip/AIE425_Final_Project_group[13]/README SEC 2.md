
# Hybrid Course Recommendation System (Coursera)

# Project Overview

This project implements a hybrid recommendation system for online courses on a MOOC platform (Coursera).
The system combines content-based filtering, collaborative filtering, and Hybrid strategies to generate personalized course recommendations while effectively handling data sparsity and cold-start problems.

The implementation follows the project specifications and is organized into clear, modular sections covering data preparation, feature engineering, modeling, and analysis.

_________________________________________________________________________________________________________________________________________________

# Objectives

. Build a scalable recommendation system for online courses
. Address extreme sparsity in user–course interactions
. Handle cold-start users and items
. Combine multiple recommendation techniques for better performance
. Provide clear analysis and visualizations to justify design choices

__________________________________________________________________________________________________________________________________________________

# Datasets Used

Two public Coursera datasets from Kaggle were used:

1. Course Reviews Dataset

   * User reviews and ratings
   * Fields: reviewer ID, course ID, rating, review text, date
   https://www.kaggle.com/datasets/imuhammad/course-reviews-on-coursera

2. Course Metadata Dataset

   * Rich course information
   * Fields: course title, skills, category, difficulty level, institution, duration, number of reviews
   https://www.kaggle.com/datasets/elvinrustam/coursera-dataset

The datasets were cleaned, normalized, deduplicated, and <merged using normalized course titles.

_________________________________________________________________________________________________________________________________________________ 
# Data Preparation & Cleaning

Key preprocessing steps include:

. Text normalization (lowercasing, removing punctuation)
. Deduplication of courses and reviews
. Removal of invalid or low-quality records
. Standardization of categorical fields (e.g., Level, Keyword)
. Handling missing values appropriately
. Preserving sparsity where required by design

_________________________________________________________________________________________________________________________________________________

# Exploratory Data Analysis

The following analyses and visualizations were created:

. Rating distribution (1–5 stars)
. User activity distribution (reviews per user)
. Course popularity and long-tail analysis
. Average rating trends over time
. Dataset sparsity and density calculations

These analyses confirm:

* <Extreme sparsity (~99.7%)
* Strong <long-tail behavior
* High percentage of <cold-start users

__________________________________________________________________________________________________________________________________________________

# Feature Engineering

# 1. Text Features (TF-IDF)

* Method: <TF-IDF Vectorization
* Sources:

  * Course title (weighted ×3)
  * Skills (×2)
  * Keyword/category (×2)
  * Modules description (×1)
* Configuration:

  * Unigrams & bigrams
  * Vocabulary size: 500
  * Stop-word removal and tokenization

# 2. Categorical Features

* One-hot encoded:

  * Keyword (course domain)
  * Level (Beginner, Intermediate, Advanced, etc.)
  * Offered By (institution)
* Unknown values handled explicitly

# 3. Numerical Features

* Duration to complete
* Number of reviews
* Normalized using **StandardScaler**

# Final Item-Feature Matrix

* Shape: `(537 courses × 646 features)`
* High sparsity preserved for realism
* Combined using sparse matrix operations

__________________________________________________________________________________________________________________________________________________

# User Profile Construction

# Weighted User Profiles

* User profiles are built as <weighted averages of item feature vectors
* Weights are based on explicit user ratings (1–5)

# Cold-Start Handling

* Users with ≤ 5 ratings are treated as cold-start
* Strategy: Popularity-based initialization

  * Average feature vector of top popular courses
* Ensures valid recommendations even with limited user data

__________________________________________________________________________________________________________________________________________________

# Recommendation Strategy

The system supports:

* Content-based similarity (cosine similarity)
* Collaborative filtering (rating-based patterns)
* Hybrid integration (used in later stages)

This design allows:

* Personalization for active users
* Reasonable defaults for new users
* Robustness against sparsity

__________________________________________________________________________________________________________________________________________________

# Key Challenges Addressed

1. Extreme Data Sparsity
2. Cold-Start Users and Items
3. Long-Tail Distribution Bias

Each challenge is explicitly analyzed and addressed through model design and feature selection.

__________________________________________________________________________________________________________________________________________________

# Technologies Used

* Python
* Pandas, NumPy
* Scikit-learn
* NLTK
* SciPy (sparse matrices)
* Matplotlib
* Google Colab

__________________________________________________________________________________________________________________________________________________

#  Outputs

* Cleaned and merged datasets
* Feature matrices
* User profiles
* Visualizations (PNG files)
* Reproducible notebook with documented steps

__________________________________________________________________________________________________________________________________________________

# Conclusion

This project demonstrates a complete, well-justified hybrid recommendation system for online courses.
The implementation balances theoretical correctness  with practical constraints, making it suitable for real-world MOOC platforms and academic evaluation.

__________________________________________________________________________________________________________________________________________________

